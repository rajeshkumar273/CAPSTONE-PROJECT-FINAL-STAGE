package com.ecommerce.application.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.application.modal.Admin;



public interface AdminRepo extends JpaRepository<Admin, Integer>{

}