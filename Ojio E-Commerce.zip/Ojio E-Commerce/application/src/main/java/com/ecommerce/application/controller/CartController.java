package com.ecommerce.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.ecommerce.application.modal.Cart;
import com.ecommerce.application.repo.CartRepo;


public class CartController {
	@Autowired
	private CartRepo cartRepo;
	
	 @PostMapping("/cartRepo")
	    public Cart createCart(@RequestBody Cart reg) {
	        return cartRepo.save(reg);
	    }
	 @GetMapping("/cartlogin")
	    public List < Cart > checkUser() {
	        return cartRepo.findAll();
	 }
}




